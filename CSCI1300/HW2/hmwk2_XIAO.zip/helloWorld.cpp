// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326 - Sanskar Katiyar 
// Homework2- problem #1

#include <iostream>
using namespace std;
//print Hello, World!
int main(){
    cout << "Hello, World!" << endl;
    return 0;
}