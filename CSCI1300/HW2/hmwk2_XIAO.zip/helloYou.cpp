// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326 - Sanskar Katiyar 
// Homework2- problem #2

#include <iostream>
using namespace std;

int main(){
    /* 
    1. ask for name of the user
    2. store input in variable name
    3. print Hello, name!
     */
    string name;
    cout << "Enter your name: " << endl;
    cin >> name;
    cout << "Hello, " << name << "! " << endl; 
    return 0;
}