#include "Book.h" 
#include <iostream>
#include <string>

using namespace std;

Book::Book()
{
    title = "";
    author = "";
    genre = "";
}

Book::Book(string s1,string s2, string s3)
{
    title = s1;
    author = s2;
    genre = s3;
}

void Book::setTitle(string s1)
{
    title = s1;
}
void Book::setAuthor(string s2)
{
    author = s2;
}
void Book::setGenre(string s3)
{
    genre = s3;
}

string Book::getTitle()const
{
    return title;
}
string Book::getAuthor()const
{
    return author;
}
string Book::getGenre()const
{
    return genre;
}
