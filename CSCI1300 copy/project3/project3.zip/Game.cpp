// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326- Sanskar Katiyar
// Project 3

#include "Game.h"
#include "Player.h"
#include "Inventory.h"
#include <string>
#include <iostream>
#include <vector>
using namespace std;
Game::Game()
{
    for (int i = 0; i< 10; i++)
    {
        players[i].setUsername("");
        players[i].setScore(0); 
        players[i].setHealth(0);
    }
}
Game::Game(vector<Player> players, int num)
{
    for (int i = 0; i < num_players; i++)
    {
        //setting vector of player objects 
        this-> players[i] = players[i];
    }
}
//setters
void Game::setPlayerNameAt(int index, string name)
{
    players[index].setUsername(name);//setting user name
}
void Game::setPointsAt(int index, int points)
{
    players[index].setScore(points);//setting score
}
void Game::setHealthAt(int index, int health)
{
    players[index].setHealth(health);//setting health 
}
//getters
string Game::getNameAt(int index)const 
{
    return players[index].getUsername();//return player name at index
}
int Game::getPointsAt(int index)const
{
    return players[index].getScore();//return # of points at index
}
int Game::getHealthAt(int index)const
{
    return players[index].getHealth();//return health score
}
int Game::getNumPlayers()const
{
    return players.size();//get # of players in vector
}

void Game::printMenu()//prints menu of options to user
{
    // this is the outline of the menu
    // cout << "1. continue on trail
    // 2. stop to rest
    // 3. etc
    // 4.
    // 5.
    // 6.
    // 7.
    // 8.
    // "
    // << endl;
}

void Game::run(){
    // This is the function that is going to run the game
        // All of the function calls will be in here so in the main cpp file, it will be clean and just say run
        // instead of having all of the code
        // While the option equals a certain num, it will perform the corresponding task
        int option;
        string s;
        
    while (option != 8)
    {
        printMenu();
        getline(cin, s); 
        option = stoi(s);
        switch(option)
        {
            case 1: 
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
        }
    }
}
//will include inventory
