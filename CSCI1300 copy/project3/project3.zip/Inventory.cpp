// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326- Sanskar Katiyar
// Project 3 
#include "Inventory.h"
#include <string>
using namespace std;

Inventory::Inventory()//default constructor
{
    food_remaining = 0;
    cash_available = 0;
    ammunition = 0;
    num_oxen = 0;
    medical_kits = 0;
    wagon_parts = 0;
}
Inventory::Inventory(int food_remaining, int cash_available, int ammunition, int num_oxen, int medical_kits, int wagon_parts)
{//parameterized constructor
    this-> food_remaining = food_remaining;
    this-> cash_available = cash_available;
    this-> ammunition = ammunition;
    this-> num_oxen = num_oxen;
    this-> medical_kits = medical_kits;
    this-> wagon_parts = wagon_parts;
}

//setters- setting values for all items in inventory
void Inventory::setFoodRemaining(int food_remaining)
{
    this-> food_remaining = food_remaining;
}
void Inventory::setCashAvailable(int cash_available)
{
    this-> cash_available = cash_available;
}
void Inventory::setAmmunition(int ammunition)
{
    this-> ammunition = ammunition;
}
void Inventory::setOxen(int num_oxen)
{
    this-> num_oxen = num_oxen;
}
void Inventory::setMedicalKits(int medical_kits)
{
    this-> medical_kits = medical_kits;
}
void Inventory::setWagonParts(int wagon_parts)
{
    this-> wagon_parts = wagon_parts;
}

//getters- returns int value
int Inventory::getCashAvailable() const
{
    return cash_available;
}
int Inventory::getFoodRemaining() const
{
    return food_remaining;
}
int Inventory::getAmmunition() const
{
    return ammunition;
}
int Inventory::getOxen() const
{
    return num_oxen;
}
int Inventory::getMedicalKits() const
{
    return medical_kits; 
}
int Inventory::getWagonParts() const
{
    return wagon_parts;
}
    