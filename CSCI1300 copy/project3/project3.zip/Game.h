// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326- Sanskar Katiyar
// Project 3
#ifndef GAME_H
#define GAME_H
#include <string>
#include <vector>
#include "Player.h"
#include "Inventory.h"
using namespace std;
class Game
{
    public:
    Game();
    Game(vector<Player> players, int num);

    //setters
    void setPlayerNameAt(int index, string name); 
    void setPointsAt(int index, int points);
    void setHealthAt(int index, int health);

    //getters
    string getNameAt(int index)const;//return player name at index
    int getPointsAt(int index)const;//return # of points at index
    int getHealthAt(int index)const; 
    int getNumPlayers()const;//get # of players in vector
    
    void printMenu();
    void run();
    
    private:
    vector<Player> players; //vector of player objects
    int points;
    int num_players;
    Inventory inv;
};
#endif