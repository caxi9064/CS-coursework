// CS1300 Fall 2020
// Author: Catherine Xiao
// Recitation: 326- Sanskar Katiyar
// Project 3 
#ifndef INVENTORY_H
#define INVENTORY_H
#include <string>
using namespace std;

class Inventory
{
    public: 
    Inventory();
    Inventory(int food_remaining, int cash_available, int ammunition, int num_oxen, int medical_kits, int wagon_parts);

    //setters
    void setCashAvailable(int food_remaining);
    void setFoodRemaining(int cash_available);
    void setAmmunition(int ammunition);
    void setOxen(int num_oxen);
    void setMedicalKits(int medical_kits);
    void setWagonParts(int wagon_parts);


    //getters
    int getCashAvailable() const;
    int getFoodRemaining() const;
    int getAmmunition() const;
    int getOxen() const;
    int getMedicalKits() const;
    int getWagonParts() const;

    private: 
    int food_remaining; 
    int cash_available;
    int ammunition;
    int num_oxen;
    int medical_kits; 
    int wagon_parts; 
};

#endif