def shortest_path_grid(grid, start, goal):
    '''
    Function that returns the length of the shortest path in a grid
    that has no obstacles. The length is simply the number of cells
    on the path including the 'start' and the 'goal'

    :param grid: list of lists (represents a square grid)
    :param start: tuple of start index
    :param goal: tuple of goal index
    :return: length of path
    '''
    n = len(grid)


if __name__ == "__main__":
    grid = [[0,0,0],
            [0,0,0],
            [0,0,0]]
    start, goal = (0,0), (2,1)
    print(shortest_path_grid(grid, start, goal))
    assert shortest_path_grid(grid, start, goal) == 4

